from flask import Flask, request , jsonify
from flask_socketio import SocketIO, emit
from QDrant import QDrant

from login_with_google import Login
from QandA import QuestionAndAnswer

app = Flask("SeuQuest")
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)

googleLogin = Login()
qNa = QuestionAndAnswer()


url = "https://27336f90-caee-4940-b82e-5e0a5b9bcced.europe-west3-0.gcp.cloud.qdrant.io"
api_key = "iiU1LO1KFU1eO0UE_ZZA1ejx2OpIS0DxRzKIvxXSoM-UJGEjurRdDA"

qdrant = QDrant(
    url, api_key
)


@app.route("/search", methods=["POST"])
def search():
    json = request.get_json()
    
    query = json.get('query', None)
    metadata = json.get("metadata", None) # {"must": {"data": ["other"]}}

    if query is None or metadata is None:
        return jsonify({"OK":False,"error": "Required parameters missing"}), 400
    
    results = qdrant.search_vectors(query,metadata)
    page_contents = ""

    for result in results:
        if result.score >= 0.5:
            page_contents += "\n"
            page_contents += result.payload["page_content"]

    return jsonify({"OK":True,"context":page_contents}),200


@app.route("/create-collection", methods=["POST"])
def create_collection():
    json = request.get_json()
    collection_name = json.get("collection_name", None)

    if collection_name is None:
        return jsonify({"OK":False,"error": "Required parameters missing"}), 400
    
    result = qdrant.new_collection(collection_name)
    return jsonify({"OK":True,"results":result}),200
    

@app.route('/train', methods=['POST'])
def train():
    json = request.get_json()

    data = json.get('data', None)
    metadata = json.get("metadata",None) # {"data": "other"}

    if data is None or metadata is None:
        return jsonify({"OK":False,"error": "Required parameters missing"}), 400

    result = qdrant.train(data, metadata)
    return jsonify({'Ok':True,'result': result})


@app.route('/login/', methods=['POST','GET'])
def login():
    return googleLogin.login_request()

@app.route('/login/callback', methods=['POST','GET'])
def login_callback():
    return googleLogin.login_callback(request)

@app.route('/login/credentials', methods=['GET'])
def login_credentials():
    if len(googleLogin.login_credentials) > 0:
        context = googleLogin.getCredentials()
        googleLogin.setCredentials({})
        context["status"] = "200"

        return jsonify(context) , 200
    else:
        context = googleLogin.getCredentials()
        googleLogin.setCredentials({})
        context["status"] = "401"

        return jsonify(context) , 401

@app.route('/text-similarity',methods=['POST'])
def textSimilarity():
    json = request.get_json()
    file_path = json.get('file_path')
    file_type = json.get('file_type')
    question = json.get('question')

    if(file_path != qNa.file_path):
        extracted_text = qNa.exract_text(file_path, file_type)
        qNa.get_text_chunks(extracted_text)


    similar_texts = qNa.cosign_similarity(question,4)

    texts = ""
    for text in similar_texts:
        texts += text + "\n"

    context = {
        "OK":True,
        "context":texts
    }
    print(context)

    return jsonify(context)

if __name__ == '__main__':
    app.run(debug=True)