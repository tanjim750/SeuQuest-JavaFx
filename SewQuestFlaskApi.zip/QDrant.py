from qdrant_client import QdrantClient
from qdrant_client.http import models as QdrantModel
from qdrant_client.http import models as qdrant_models

from langchain.vectorstores import Qdrant
from langchain.embeddings import HuggingFaceInstructEmbeddings
from langchain.text_splitter import CharacterTextSplitter
from langchain.document_loaders.csv_loader import CSVLoader
import spacy

embeddings = HuggingFaceInstructEmbeddings(model_name="hkunlp/instructor-large")

class QDrant:
    """
    The `QDRANT` class is a Python class that provides methods for interacting with the QDRANT
    vector database, including loading collections, training collections with data, and overwriting
    payload for specific points in a collection.
    """
    def __init__(self,url,api_key):
        self.url = url
        self.api_key = api_key
        self.collection_name = "seuquestdb"
        self.client_ = self.client()
        self.vectordb = self.load()

    def client(self):
        """
        The function creates and returns a QdrantClient object with the specified URL and API key.
        :return: an instance of the QdrantClient class.
        """
        client_ = QdrantClient(

            url=self.url,
            api_key=self.api_key,
        )
        return client_

    def load(self):
        """
        The function loads a collection from a Qdrant database and returns the loaded collection.

        :param collection_name: The `collection_name` parameter is the name of the collection in the
        Qdrant database where you want to load the vectors
        :return: The `load` function returns the `vectordb` object.
        """
        vectordb = Qdrant(
                client=self.client_,
                collection_name=self.collection_name,
                embeddings=embeddings
            )

        return vectordb

    def new_collection(self,collection_name,document=False):
        collection_config = QdrantModel.VectorParams(
            size=768, # 768 for instructor-xl, 1536 for OpenAI
            distance=QdrantModel.Distance.COSINE
        )

        result = self.client_.recreate_collection(
            collection_name=collection_name,
            vectors_config=collection_config
        )

        return result
    
    def search_vectors(self,query,metadata, limit=4):
        filter_ = self.qdrant_metadata_filtering(metadata)
        query_vector = embeddings.embed_query(query)

        result = self.client_.search(
            collection_name=self.collection_name,
            query_vector=query_vector,
            query_filter = filter_,
            limit=limit
        )

        return result

    def train(self,data,metadata):
        """
        The train function takes in data and metadata, cleans the text, splits it into multiple
        texts, adds the texts and metadata to a vector database, and returns the vector database.

        :param data: The "data" parameter is the input text data that you want to train the model
        on. It could be a single string or a list of strings, depending on how you want to structure
        your training data
        :param metadata: The metadata parameter is a piece of additional information associated with
        each text in the data. It can be any relevant information that you want to store and
        associate with the texts
        :return: The code is returning the instance of the vectordb object.
        """
        texts = self.text_splitter(data)
        metadata_list = [metadata for i in range(len(texts))]
        result = self.vectordb.add_texts(texts=texts,metadatas=metadata_list)
        return result

    def overwrite_payload(self,collection_name:str,points:list[str,int],payload:dict):
        """
        The function `overwrite_payload` takes in a collection name, a list of points, and a payload
        dictionary, and calls a method to overwrite the payload for the specified points in the
        specified collection.

        :param collection_name: The name of the collection where the payload will be overwritten
        :type collection_name: str
        :param points: The "points" parameter is a list of strings and integers. It represents the
        points or coordinates in the collection that you want to overwrite with the new payload.
        Each element in the list should be a string or an integer
        :type points: list[str,int]
        :param payload: The `payload` parameter is a dictionary that contains the data you want to
        overwrite for the specified points in the collection. It should have key-value pairs where
        the keys represent the fields in the collection and the values represent the new values you
        want to set for those fields
        :type payload: dict
        :return: The result of the `overwrite_payload` method is being returned.
        """
        result = self.client_.overwrite_payload(collection_name=collection_name,points=points,payload=payload)
        return result
        
    @staticmethod
    def text_splitter(text):
        """
        The function `text_splitter` takes in a text and splits it into chunks of a specified size, with
        a specified overlap, using a character separator.

        :param text: The input text that you want to split into chunks
        :return: the split text.
        """
        spliter = CharacterTextSplitter(separator="\n",chunk_size=4080,chunk_overlap=50)
        split_text = spliter.split_text(text)
        return split_text

    @staticmethod
    def text_cleaner(text_data):
        """
        The function `text_cleaner` takes in a string of text data, removes stop words and punctuation
        using the spaCy library, and returns the cleaned text as a string.

        :param text_data: The `text_data` parameter is a string that represents the input text that you
        want to clean
        :return: The function `text_cleaner` returns the cleaned text data after removing stop words and
        punctuation.
        """
        nlp = spacy.load("en_core_web_md")
        doc = nlp(text_data)
        clean_tokens = [token.text for token in doc if (token.text == "." or token.text == ":") or (not token.is_stop and not token.is_punct)]
        cleaned_text = " ".join(clean_tokens)
        return cleaned_text

    @staticmethod
    def csv_splitter(file):
        """
        The function `csv_splitter` takes a file as input, loads the CSV data from the file using a
        CSVLoader object, and returns the extracted data.

        :param file: The "file" parameter is the path or name of the CSV file that you want to split
        :return: the extracted data from the CSV file.
        """
        load_csv = CSVLoader(file)
        extract_data = load_csv.load()
        return extract_data


    def qdrant_metadata_filtering(self,metadatas):
        # qdrant filtering (must)
        must:dict = metadatas.get("must",None)
        filter_must = []
        if must is not None:
            for key,values in must.items():
                for value in values:
                    condition = qdrant_models.FieldCondition(
                                        key="metadata."+str(key),
                                        match=qdrant_models.MatchValue(value=str(value))
                                    )
                    filter_must.append(condition)

        # qdrant filtering (must_not)
        must_not:dict = metadatas.get("must_not",None)
        filter_must_not = []
        if must_not is not None:
            for key,values in must_not.items():
                for value in values:
                    condition = qdrant_models.FieldCondition(
                                    key="metadata."+str(key),
                                    match=qdrant_models.MatchValue(value=str(value))
                                )
                    filter_must_not.append(condition)

        # qdrant filtering (should)
        should:dict = metadatas.get("should",None)
        filter_should = []
        if should is not None:
            for key,values in should.items():
                for value in values:
                    condition = qdrant_models.FieldCondition(
                                    key="metadata."+str(key),
                                    match=qdrant_models.MatchValue(value=str(value))
                                )
                    filter_should.append(condition)

        filter_ = qdrant_models.Filter(
                must=[must_ for must_ in filter_must],
                must_not=[must_not_ for must_not_ in filter_must_not],
                should = [should_ for should_ in filter_should]
                )

        return filter_