import os
import pathlib

import requests
from google.oauth2 import id_token
from google_auth_oauthlib.flow import Flow
from pip._vendor import cachecontrol
import google.auth.transport.requests

from flask import redirect, jsonify

os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

GOOGLE_CLIENT_ID = "741810732637-46srvkc0rphe19qu9s6n1b4esm02j2i4.apps.googleusercontent.com"
client_secrets_file = os.path.join(pathlib.Path(__file__).parent, "client_secret.json")



flow = Flow.from_client_secrets_file(
    client_secrets_file=client_secrets_file,
    scopes=["https://www.googleapis.com/auth/userinfo.profile", "https://www.googleapis.com/auth/userinfo.email", "openid"],
    redirect_uri="http://127.0.0.1:5000/login/callback"
)

class Login:
    def __init__(self):
        self.login_credentials = {}

    def login_request(self):
        authorization_url, state = flow.authorization_url()
        return redirect(authorization_url)

    def login_callback(self,request):
        flow.fetch_token(authorization_response=request.url)

        credentials = flow.credentials
        request_session = requests.session()
        cached_session = cachecontrol.CacheControl(request_session)
        token_request = google.auth.transport.requests.Request(session=cached_session)

        id_info = id_token.verify_oauth2_token(
            id_token=credentials._id_token,
            request=token_request,
            audience=GOOGLE_CLIENT_ID
        )

        name = id_info.get("name",None)
        picture = id_info.get("picture",None)
        email = id_info.get("email",None)
        hd = id_info.get("hd","")

        context = {
            "name": name,
            "picture": picture,
            "email": email,
            "hd": hd,
        }

        self.login_credentials = context

        return "Successfully logged in. back to application and confirm login"
    
    def getCredentials(self):
        return self.login_credentials
    
    def setCredentials(self, credentials):
        self.login_credentials = credentials
        return self.login_credentials

