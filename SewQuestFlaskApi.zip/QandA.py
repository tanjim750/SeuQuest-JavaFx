from PyPDF2 import PdfReader
from langchain.text_splitter import CharacterTextSplitter, TokenTextSplitter

import torch
from transformers import AutoTokenizer, AutoModel
from sklearn.metrics.pairwise import cosine_similarity

class QuestionAndAnswer:
    def __init__(self):
        self.text_chunks = []
        self.file_path = ""

    def exract_text(self,file_path,file_type):
        text = ""
        self.file_path = file_path

        if file_type == "pdf":
            try:
                pdf_reader = PdfReader(self.file_path)
                for page in pdf_reader.pages:
                    text += page.extract_text()
            except:
                pass
        else:
            file = open(self.file_path, 'r')
            lines = file.readlines()
            for line in lines:
                text += line
            file.close()
        
        return text
    
    def get_text_chunks(self,text):
        text_splitter = CharacterTextSplitter(
            separator="\n",
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len
        )

        chunks = text_splitter.split_text(text)
        self.text_chunks = chunks
        return chunks
    
    def cosign_similarity(self,source_sen:str,limits:int=1):
        sentences = [
            source_sen
        ]

        

        for chunk in self.text_chunks:
            sentences.append(chunk)

        model_name = 'sentence-transformers/all-MiniLM-L6-v2'
        # model_name = 'sentence-transformers/bert-base-nli-mean-tokens'

        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModel.from_pretrained(model_name)

        # initialize dictionary to store tokenized sentences
        tokens = {'input_ids': [], 'attention_mask': []}

        for sentence in sentences:
            # encode each sentence and append to dictionary
            new_tokens = tokenizer.encode_plus(sentence, max_length=128,
                                                truncation=True, padding='max_length',
                                                return_tensors='pt')
            tokens['input_ids'].append(new_tokens['input_ids'][0])
            tokens['attention_mask'].append(new_tokens['attention_mask'][0])

        # reformat list of tensors into single tensor
        tokens['input_ids'] = torch.stack(tokens['input_ids'])
        tokens['attention_mask'] = torch.stack(tokens['attention_mask'])

        outputs = model(**tokens)
        outputs.keys()

        embeddings = outputs.last_hidden_state
        embeddings.shape

        attention_mask = tokens['attention_mask']
        attention_mask.shape

        mask = attention_mask.unsqueeze(-1).expand(embeddings.size()).float()
        mask.shape

        masked_embeddings = embeddings * mask
        masked_embeddings.shape

        summed = torch.sum(masked_embeddings, 1)
        summed.shape

        summed_mask = torch.clamp(mask.sum(1), min=1e-9)
        summed_mask.shape

        mean_pooled = summed / summed_mask


        # convert from PyTorch tensor to numpy array
        mean_pooled = mean_pooled.detach().numpy()

        # calculate
        simiarity: list = (cosine_similarity(
            [mean_pooled[0]],
            mean_pooled[1:]
        )).tolist()
        
        simiarity_priority = sorted(simiarity, reverse=True)
        print(simiarity_priority)
        similar_sentences = []

        for limit in range(0,limits+1):
            try:
                idx = simiarity.index(simiarity_priority[limit]) + 1 # adding index by 1
                similar_sentences.append(sentences[idx])
            except:
                pass

        return similar_sentences